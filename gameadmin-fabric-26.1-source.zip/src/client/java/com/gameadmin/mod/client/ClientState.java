package com.gameadmin.mod.client;

import com.gameadmin.mod.Ability;
import com.gameadmin.mod.FeedbackPayload;

/** Client-side memory: when each ability is ready again, and what was cast last. */
public final class ClientState {
    private ClientState() {}

    public static final long[] COOLDOWN_END = new long[Ability.ALL.length];
    public static int lastCast = -1;

    public static long remainingMs(int ability) {
        return Math.max(0L, COOLDOWN_END[ability] - System.currentTimeMillis());
    }

    public static void onFeedback(FeedbackPayload p) {
        if (p.ability() < 0 || p.ability() >= Ability.ALL.length) return;
        Ability a = Ability.ALL[p.ability()];
        long now = System.currentTimeMillis();
        if (p.status() == FeedbackPayload.CAST) {
            COOLDOWN_END[p.ability()] = now + a.cooldownMs;
            Vfx.start(p.ability(), p.value());
        } else {
            COOLDOWN_END[p.ability()] = now + p.value();
            Vfx.toast(a.label + " is recharging", a.rgb);
        }
    }
}
