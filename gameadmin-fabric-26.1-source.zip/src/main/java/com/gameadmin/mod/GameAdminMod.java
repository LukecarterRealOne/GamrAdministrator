package com.gameadmin.mod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Common entrypoint: registers the two network messages and the server-side cast handler. */
public class GameAdminMod implements ModInitializer {
    public static final String MOD_ID = "gameadmin";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        PayloadTypeRegistry.serverboundPlay().register(CastRequestPayload.TYPE, CastRequestPayload.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(FeedbackPayload.TYPE, FeedbackPayload.CODEC);

        // Runs on the server thread.
        ServerPlayNetworking.registerGlobalReceiver(CastRequestPayload.TYPE,
                (payload, context) -> AbilityManager.handleCast(context.player(), payload.ability()));

        LOGGER.info("Game Administrator loaded. You are in charge.");
    }
}
